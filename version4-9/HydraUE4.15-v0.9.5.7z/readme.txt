Quick Install & Setup

1. Download Latest Release
2. Create new or choose project.
3. Browse to your project folder (typically found at Documents/Unreal Project/{Your Project Root})
4. Copy Plugins folder into your Project root.
5. Restart the Editor and open your project again. Plugin is now ready to use.

Refer to https://github.com/getnamo/hydra-ue4 for detailed instructions